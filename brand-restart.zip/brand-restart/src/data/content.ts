export const siteConfig = {
  name: "Brand Restart",
  founder: "Stelios Mytadis",
  email: "hello@brandrestart.eu",
  instagram: "https://instagram.com/brandrestart",
  useme: "https://useme.com/en/roles/freelancer/stelios-mytadis",
  price: "From €690",
  delivery: "10 business days",
};

export const projects = [
  {
    id: "project-one",
    title: "Nordic Craft Co.",
    category: "Brand Restart",
    status: "Concept project",
    summary:
      "The original mark relied on thin linework and a dated serif that disappeared at small sizes. The redesign retained the core geometric structure while introducing a stronger weight, clearer proportions and a practical secondary lock-up for digital use.",
    beforeLabel: "Before",
    afterLabel: "After",
  },
  {
    id: "project-two",
    title: "Atlas Engineering",
    category: "Brand Restart",
    status: "Concept project",
    summary:
      "Recognition was strong but the identity felt fragmented across materials. The new system preserved the familiar monogram while unifying colour, type and spacing so the brand reads as one coherent, contemporary whole.",
    beforeLabel: "Before",
    afterLabel: "After",
  },
];

export const deliverables = [
  {
    number: "01",
    title: "Brand and competitor audit",
    description:
      "A focused review of your current identity, market and visual positioning.",
  },
  {
    number: "02",
    title: "Creative direction",
    description:
      "A clear visual direction grounded in the character and goals of your business.",
  },
  {
    number: "03",
    title: "Complete logo suite",
    description: "Primary logo, secondary version and flexible brand icon.",
  },
  {
    number: "04",
    title: "Colour and typography system",
    description:
      "A consistent visual system designed for digital and print use.",
  },
  {
    number: "05",
    title: "Mini brand guidelines",
    description: "A practical guide showing how to use the identity correctly.",
  },
  {
    number: "06",
    title: "Professional final files",
    description:
      "AI, SVG, EPS, PDF, PNG and JPG exports organised for immediate use.",
  },
];

export const processSteps = [
  {
    number: "01",
    title: "Discover",
    description:
      "We examine your business, audience, competitors and existing identity.",
  },
  {
    number: "02",
    title: "Rebuild",
    description:
      "A stronger creative direction and complete identity system are developed.",
  },
  {
    number: "03",
    title: "Refine",
    description:
      "You provide structured feedback through two revision rounds.",
  },
  {
    number: "04",
    title: "Relaunch",
    description: "You receive an organised brand system ready for use.",
  },
];

export const pricingIncluded = [
  "Brand audit",
  "Creative direction",
  "Complete logo suite",
  "Colour and typography system",
  "Mini brand guidelines",
  "Social profile essentials",
  "Professional source files",
  "Two revision rounds",
];

export const faqs = [
  {
    question: "Will I lose the recognition of my existing brand?",
    answer:
      "No. The objective is to preserve valuable recognition while correcting the elements that make the identity feel outdated or inconsistent.",
  },
  {
    question: "How long does the project take?",
    answer:
      "The standard Brand Restart process is completed within 10 business days, provided feedback is delivered within the agreed timeframe.",
  },
  {
    question: "How many revisions are included?",
    answer: "Two structured revision rounds are included in the package.",
  },
  {
    question: "Do I receive the editable files?",
    answer:
      "Yes. You receive organised source files and exports suitable for both digital and print use.",
  },
  {
    question: "How are contracts and payments handled?",
    answer:
      "The agreement, invoicing and payment are handled securely through Useme before the project begins.",
  },
];

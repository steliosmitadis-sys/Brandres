import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { Problem } from "./components/Problem";
import { Work } from "./components/Work";
import { Deliverables } from "./components/Deliverables";
import { Process } from "./components/Process";
import { Founder } from "./components/Founder";
import { Pricing } from "./components/Pricing";
import { FAQ } from "./components/FAQ";
import { Apply } from "./components/Apply";
import { Footer } from "./components/Footer";

function App() {
  return (
    <>
      <Navigation />
      <main>
        <Hero />
        <Problem />
        <Work />
        <Deliverables />
        <Process />
        <Founder />
        <Pricing />
        <FAQ />
        <Apply />
      </main>
      <Footer />
    </>
  );
}

export default App;

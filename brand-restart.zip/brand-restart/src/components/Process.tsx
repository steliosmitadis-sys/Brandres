import { processSteps } from "../data/content";

export function Process() {
  return (
    <section id="process" className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <h2 className="mb-12 max-w-lg text-[32px] font-semibold tracking-tight text-primary-text sm:text-[40px] lg:mb-16">
          A focused process. No endless meetings.
        </h2>

        <ol className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {processSteps.map((step, index) => (
            <li key={step.number} className="relative">
              {index < processSteps.length - 1 && (
                <div
                  className="absolute left-[28px] top-8 hidden h-px w-[calc(100%-28px)] bg-border lg:block"
                  aria-hidden
                />
              )}
              <div className="mb-4 flex h-8 w-8 items-center justify-center rounded-full border border-border bg-surface text-[13px] font-semibold text-primary-text">
                {step.number}
              </div>
              <h3 className="mb-2 text-[17px] font-semibold text-primary-text">
                {step.title}
              </h3>
              <p className="text-[15px] leading-relaxed text-secondary-text">
                {step.description}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

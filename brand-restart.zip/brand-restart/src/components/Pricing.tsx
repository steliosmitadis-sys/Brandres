import { pricingIncluded, siteConfig } from "../data/content";

export function Pricing() {
  return (
    <section className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <div className="mx-auto max-w-2xl">
          <h2 className="mb-10 text-center text-[32px] font-semibold tracking-tight text-primary-text sm:text-[40px]">
            One focused package
          </h2>

          <div className="overflow-hidden rounded-xl border border-border bg-surface">
            <div className="border-b border-border px-6 py-8 sm:px-10 sm:py-10">
              <p className="mb-1 text-[13px] font-semibold uppercase tracking-[0.1em] text-fire-orange">
                Brand Restart
              </p>
              <p className="mb-1 text-[40px] font-semibold tracking-tight text-primary-text sm:text-[48px]">
                {siteConfig.price}
              </p>
              <p className="text-[15px] text-secondary-text">
                Delivered in {siteConfig.delivery}
              </p>
            </div>

            <div className="px-6 py-8 sm:px-10">
              <ul className="mb-8 space-y-3">
                {pricingIncluded.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <svg
                      className="mt-0.5 h-5 w-5 shrink-0 text-fire-orange"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                      aria-hidden
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <span className="text-[15px] text-primary-text">{item}</span>
                  </li>
                ))}
              </ul>

              <p className="mb-6 text-[13px] leading-relaxed text-secondary-text">
                Contracts, invoicing and secure payment are handled through
                Useme.
              </p>

              <a
                href="#apply"
                className="flex w-full items-center justify-center rounded-md bg-fire-orange px-6 py-3.5 text-[15px] font-medium text-white transition-colors duration-150 hover:bg-deep-orange"
              >
                Apply for Brand Restart
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { siteConfig } from "../data/content";

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface py-12 sm:py-16">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <div className="flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="mb-1 text-[15px] font-semibold text-primary-text">
              Brand Restart by {siteConfig.founder}
            </p>
            <p className="max-w-xs text-[13px] leading-relaxed text-secondary-text">
              Independent brand identity designer based in Greece and working
              across Europe.
            </p>
          </div>

          <div className="flex flex-col gap-2 text-[13px]">
            <a
              href={`mailto:${siteConfig.email}`}
              className="text-secondary-text transition-colors hover:text-primary-text"
            >
              {siteConfig.email}
            </a>
            <a
              href={siteConfig.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="text-secondary-text transition-colors hover:text-primary-text"
            >
              Instagram
            </a>
            <a
              href={siteConfig.useme}
              target="_blank"
              rel="noopener noreferrer"
              className="text-secondary-text transition-colors hover:text-primary-text"
            >
              Useme profile
            </a>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[12px] text-secondary-text">
            © {new Date().getFullYear()} Brand Restart. All rights reserved.
          </p>
          <div className="flex gap-5 text-[12px]">
            <a
              href="#privacy"
              className="text-secondary-text transition-colors hover:text-primary-text"
            >
              Privacy Policy
            </a>
            <a
              href="#terms"
              className="text-secondary-text transition-colors hover:text-primary-text"
            >
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useState } from "react";
import { projects } from "../data/content";

function BeforeAfterToggle({
  beforeLabel,
  afterLabel,
}: {
  beforeLabel: string;
  afterLabel: string;
}) {
  const [showAfter, setShowAfter] = useState(true);

  return (
    <div className="overflow-hidden rounded-lg border border-border bg-surface">
      <div className="relative aspect-[16/10] w-full">
        {/* Placeholder visuals — replace with real images */}
        <div
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${
            showAfter ? "opacity-0 pointer-events-none" : "opacity-100"
          }`}
          style={{ background: "#E8E4DC" }}
          aria-hidden={showAfter}
        >
          <div className="flex flex-col items-center gap-3 px-6 text-center">
            <div className="h-16 w-16 rounded-full border-2 border-dashed border-secondary-text/40" />
            <span className="text-[13px] font-medium uppercase tracking-wider text-secondary-text">
              Original identity
            </span>
          </div>
        </div>
        <div
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${
            showAfter ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
          style={{ background: "#FFF0E8" }}
          aria-hidden={!showAfter}
        >
          <div className="flex flex-col items-center gap-3 px-6 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-fire-orange text-white">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <span className="text-[13px] font-medium uppercase tracking-wider text-dark-orange">
              Redesigned system
            </span>
          </div>
        </div>
      </div>

      <div className="flex border-t border-border">
        <button
          type="button"
          onClick={() => setShowAfter(false)}
          className={`flex-1 py-3 text-[13px] font-medium transition-colors duration-150 ${
            !showAfter
              ? "bg-primary-text text-white"
              : "bg-surface text-secondary-text hover:text-primary-text"
          }`}
          aria-pressed={!showAfter}
        >
          {beforeLabel}
        </button>
        <button
          type="button"
          onClick={() => setShowAfter(true)}
          className={`flex-1 py-3 text-[13px] font-medium transition-colors duration-150 ${
            showAfter
              ? "bg-primary-text text-white"
              : "bg-surface text-secondary-text hover:text-primary-text"
          }`}
          aria-pressed={showAfter}
        >
          {afterLabel}
        </button>
      </div>
    </div>
  );
}

export function Work() {
  return (
    <section id="work" className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <h2 className="mb-12 text-[32px] font-semibold tracking-tight text-primary-text sm:text-[40px] lg:mb-16">
          Selected brand transformations
        </h2>

        <div className="space-y-16 lg:space-y-24">
          {projects.map((project, index) => (
            <article
              key={project.id}
              className={`grid items-start gap-8 lg:grid-cols-2 lg:gap-12 ${
                index % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >
              <BeforeAfterToggle
                beforeLabel={project.beforeLabel}
                afterLabel={project.afterLabel}
              />
              <div className="lg:pt-4">
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <span className="text-[12px] font-semibold uppercase tracking-[0.1em] text-fire-orange">
                    {project.category}
                  </span>
                  <span className="text-[12px] text-secondary-text">
                    · {project.status}
                  </span>
                </div>
                <h3 className="mb-4 text-[24px] font-semibold tracking-tight text-primary-text sm:text-[28px]">
                  {project.title}
                </h3>
                <p className="text-[16px] leading-relaxed text-secondary-text">
                  {project.summary}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

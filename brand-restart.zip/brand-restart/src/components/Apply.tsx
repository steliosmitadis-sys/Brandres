import { useState } from "react";
import type { FormEvent, ChangeEvent } from "react";

type FormStatus = "idle" | "loading" | "success" | "error";

interface FormData {
  fullName: string;
  email: string;
  company: string;
  country: string;
  website: string;
  outdated: string;
  startDate: string;
  budgetConfirm: string;
  consent: boolean;
}

const initialForm: FormData = {
  fullName: "",
  email: "",
  company: "",
  country: "",
  website: "",
  outdated: "",
  startDate: "",
  budgetConfirm: "",
  consent: false,
};

// Replace this endpoint with your form handling service (Formspree, Basin, custom API, etc.)
const FORM_ENDPOINT = "https://formspree.io/f/REPLACE_WITH_YOUR_ID";

export function Apply() {
  const [form, setForm] = useState<FormData>(initialForm);
  const [status, setStatus] = useState<FormStatus>("idle");
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>(
    {}
  );

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
    if (errors[name as keyof FormData]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name as keyof FormData];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const next: Partial<Record<keyof FormData, string>> = {};
    if (!form.fullName.trim()) next.fullName = "Please enter your full name.";
    if (!form.email.trim()) {
      next.email = "Please enter your business email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      next.email = "Please enter a valid email address.";
    }
    if (!form.company.trim()) next.company = "Please enter your company name.";
    if (!form.country.trim()) next.country = "Please enter your country.";
    if (!form.outdated.trim())
      next.outdated = "Please describe what currently feels outdated.";
    if (!form.budgetConfirm)
      next.budgetConfirm = "Please confirm your investment comfort level.";
    if (!form.consent)
      next.consent = "You must agree to the privacy policy to continue.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStatus("loading");
    try {
      // When FORM_ENDPOINT is configured, this will post the data.
      // For now we simulate a successful submission after a short delay.
      if (FORM_ENDPOINT.includes("REPLACE")) {
        await new Promise((r) => setTimeout(r, 900));
        setStatus("success");
        setForm(initialForm);
      } else {
        const res = await fetch(FORM_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify(form),
        });
        if (!res.ok) throw new Error("Submission failed");
        setStatus("success");
        setForm(initialForm);
      }
    } catch {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <section id="apply" className="border-t border-border py-20 sm:py-24 lg:py-28">
        <div className="mx-auto max-w-[640px] px-5 text-center sm:px-8">
          <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-pale-orange text-fire-orange">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <h2 className="mb-3 text-[28px] font-semibold tracking-tight text-primary-text">
            Application received
          </h2>
          <p className="text-[16px] leading-relaxed text-secondary-text">
            Your application has been received. I will review your brand and
            contact you personally.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section id="apply" className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[640px] px-5 sm:px-8">
        <h2 className="mb-3 text-[28px] font-semibold tracking-tight text-primary-text sm:text-[36px]">
          Ready to look as professional as your business has become?
        </h2>
        <p className="mb-10 text-[16px] leading-relaxed text-secondary-text">
          Tell me about your business and current identity. If Brand Restart is
          the right fit, I will contact you personally to arrange a short
          introductory call.
        </p>

        <form onSubmit={handleSubmit} noValidate className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field
              label="Full name"
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
              error={errors.fullName}
              required
            />
            <Field
              label="Business email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              error={errors.email}
              required
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <Field
              label="Company name"
              name="company"
              value={form.company}
              onChange={handleChange}
              error={errors.company}
              required
            />
            <Field
              label="Country"
              name="country"
              value={form.country}
              onChange={handleChange}
              error={errors.country}
              required
            />
          </div>

          <Field
            label="Website or Instagram URL"
            name="website"
            value={form.website}
            onChange={handleChange}
            placeholder="https://"
          />

          <div>
            <label
              htmlFor="outdated"
              className="mb-1.5 block text-[13px] font-medium text-primary-text"
            >
              What currently feels outdated?{" "}
              <span className="text-fire-orange">*</span>
            </label>
            <textarea
              id="outdated"
              name="outdated"
              rows={4}
              value={form.outdated}
              onChange={handleChange}
              className={`w-full rounded-md border bg-surface px-3.5 py-2.5 text-[15px] text-primary-text placeholder:text-secondary-text/60 focus:border-fire-orange focus:outline-none focus:ring-1 focus:ring-fire-orange ${
                errors.outdated ? "border-fire-orange" : "border-border"
              }`}
            />
            {errors.outdated && (
              <p className="mt-1 text-[13px] text-fire-orange">{errors.outdated}</p>
            )}
          </div>

          <Field
            label="Desired starting date"
            name="startDate"
            value={form.startDate}
            onChange={handleChange}
            placeholder="e.g. September 2026"
          />

          <div>
            <label
              htmlFor="budgetConfirm"
              className="mb-1.5 block text-[13px] font-medium text-primary-text"
            >
              Are you comfortable investing at least €690?{" "}
              <span className="text-fire-orange">*</span>
            </label>
            <select
              id="budgetConfirm"
              name="budgetConfirm"
              value={form.budgetConfirm}
              onChange={handleChange}
              className={`w-full rounded-md border bg-surface px-3.5 py-2.5 text-[15px] text-primary-text focus:border-fire-orange focus:outline-none focus:ring-1 focus:ring-fire-orange ${
                errors.budgetConfirm ? "border-fire-orange" : "border-border"
              }`}
            >
              <option value="">Select an option</option>
              <option value="yes">Yes</option>
              <option value="need-more-info">I need more information first</option>
            </select>
            {errors.budgetConfirm && (
              <p className="mt-1 text-[13px] text-fire-orange">
                {errors.budgetConfirm}
              </p>
            )}
          </div>

          <div className="pt-1">
            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                name="consent"
                checked={form.consent}
                onChange={handleChange}
                className="mt-1 h-4 w-4 rounded border-border text-fire-orange focus:ring-fire-orange"
              />
              <span className="text-[13px] leading-relaxed text-secondary-text">
                I agree to the{" "}
                <a href="#privacy" className="underline hover:text-primary-text">
                  privacy policy
                </a>{" "}
                and consent to being contacted about this application.{" "}
                <span className="text-fire-orange">*</span>
              </span>
            </label>
            {errors.consent && (
              <p className="mt-1 text-[13px] text-fire-orange">{errors.consent}</p>
            )}
          </div>

          {status === "error" && (
            <div
              role="alert"
              className="rounded-md border border-fire-orange/30 bg-pale-orange px-4 py-3 text-[14px] text-dark-orange"
            >
              Something went wrong. Please try again or email me directly. Your
              form data has been preserved.
            </div>
          )}

          <button
            type="submit"
            disabled={status === "loading"}
            className="flex w-full items-center justify-center rounded-md bg-fire-orange px-6 py-3.5 text-[15px] font-medium text-white transition-colors duration-150 hover:bg-deep-orange disabled:cursor-not-allowed disabled:opacity-70"
          >
            {status === "loading" ? "Submitting…" : "Submit my application"}
          </button>
        </form>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  value,
  onChange,
  error,
  type = "text",
  required,
  placeholder,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (e: ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <div>
      <label
        htmlFor={name}
        className="mb-1.5 block text-[13px] font-medium text-primary-text"
      >
        {label}
        {required && <span className="text-fire-orange"> *</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={`w-full rounded-md border bg-surface px-3.5 py-2.5 text-[15px] text-primary-text placeholder:text-secondary-text/60 focus:border-fire-orange focus:outline-none focus:ring-1 focus:ring-fire-orange ${
          error ? "border-fire-orange" : "border-border"
        }`}
      />
      {error && <p className="mt-1 text-[13px] text-fire-orange">{error}</p>}
    </div>
  );
}

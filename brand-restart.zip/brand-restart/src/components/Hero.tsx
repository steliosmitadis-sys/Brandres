export function Hero() {
  return (
    <section className="relative overflow-hidden pt-24 pb-16 sm:pt-28 sm:pb-20 lg:pt-32 lg:pb-24">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Copy */}
          <div className="max-w-xl">
            <p className="mb-4 text-[12px] font-semibold uppercase tracking-[0.12em] text-secondary-text">
              Brand identity redesign
            </p>
            <h1 className="mb-5 text-[42px] font-semibold leading-[1.1] tracking-tight text-primary-text sm:text-[48px] lg:text-[56px] xl:text-[64px]">
              Your business evolved. Your brand didn&apos;t.
            </h1>
            <p className="mb-8 text-[17px] leading-relaxed text-secondary-text sm:text-[18px]">
              Brand Restart transforms outdated logos into clear, modern brand
              identities without throwing away everything your customers already
              recognise.
            </p>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <a
                href="#apply"
                className="inline-flex items-center justify-center rounded-md bg-fire-orange px-6 py-3.5 text-[15px] font-medium text-white transition-colors duration-150 hover:bg-deep-orange"
              >
                Apply for Brand Restart
              </a>
              <a
                href="#work"
                className="inline-flex items-center justify-center rounded-md border border-border bg-surface px-6 py-3.5 text-[15px] font-medium text-primary-text transition-colors duration-150 hover:border-primary-text/20"
              >
                See the transformations
              </a>
            </div>

            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-[13px] text-secondary-text">
              <li className="flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-fire-orange" aria-hidden />
                Delivered in 10 business days
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-fire-orange" aria-hidden />
                Starting from €690
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-fire-orange" aria-hidden />
                Secure contracts via Useme
              </li>
            </ul>
          </div>

          {/* Video */}
          <div className="relative">
            <div className="overflow-hidden rounded-lg border border-border bg-surface shadow-[0_4px_24px_rgba(18,17,15,0.06)]">
              <div className="relative aspect-video w-full">
                {/* Poster / placeholder */}
                <div
                  className="absolute inset-0 flex items-center justify-center"
                  style={{
                    background:
                      "linear-gradient(135deg, #FF6A00 0%, #FF3D00 55%, #B92700 100%)",
                  }}
                >
                  <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wOCI+PHBhdGggZD0iTTM2IDM0djItaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40" />
                  <button
                    type="button"
                    className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-white/95 text-fire-orange shadow-lg transition-transform duration-150 hover:scale-105 focus-visible:outline-offset-4"
                    aria-label="Play video: Watch how Brand Restart works"
                  >
                    <svg
                      width="22"
                      height="22"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      aria-hidden="true"
                      className="ml-0.5"
                    >
                      <path d="M8 5.14v14l11-7-11-7z" />
                    </svg>
                  </button>
                </div>
                {/* Replace with actual <video> or iframe when URL is available:
                <video
                  id="sales-video"
                  className="h-full w-full object-cover"
                  poster="/path-to-poster.jpg"
                  controls
                  preload="metadata"
                  title="Watch how Brand Restart works"
                >
                  <source src="REPLACE_WITH_VIDEO_URL" type="video/mp4" />
                </video>
                */}
              </div>
            </div>
            <p className="mt-3 text-center text-[13px] text-secondary-text">
              A 90-second explanation of the process, deliverables and ideal
              client.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

import { deliverables } from "../data/content";

export function Deliverables() {
  return (
    <section
      id="deliverables"
      className="border-t border-border py-20 sm:py-24 lg:py-28"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <h2 className="mb-12 max-w-xl text-[32px] font-semibold tracking-tight text-primary-text sm:text-[40px] lg:mb-16">
          Everything needed for a confident relaunch
        </h2>

        <ul className="divide-y divide-border border-t border-border">
          {deliverables.map((item) => (
            <li
              key={item.number}
              className="grid gap-2 py-6 sm:grid-cols-[80px_1fr] sm:gap-8 sm:py-7"
            >
              <span className="text-[13px] font-semibold tabular-nums text-fire-orange">
                {item.number}
              </span>
              <div>
                <h3 className="mb-1 text-[17px] font-semibold text-primary-text">
                  {item.title}
                </h3>
                <p className="text-[15px] leading-relaxed text-secondary-text">
                  {item.description}
                </p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

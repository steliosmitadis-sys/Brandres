import { useState, useEffect } from "react";

const navLinks = [
  { label: "Work", target: "#work" },
  { label: "What You Get", target: "#deliverables" },
  { label: "Process", target: "#process" },
  { label: "FAQ", target: "#faq" },
];

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const handleLinkClick = () => {
    setMobileOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
        scrolled || mobileOpen
          ? "bg-background/95 backdrop-blur-sm border-b border-border"
          : "bg-transparent"
      }`}
    >
      <nav
        className="mx-auto flex h-16 max-w-[1240px] items-center justify-between px-5 sm:px-8 lg:px-10"
        aria-label="Main navigation"
      >
        <a
          href="#"
          className="text-[15px] font-semibold tracking-tight text-primary-text"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          Brand Restart
        </a>

        {/* Desktop links */}
        <div className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.target}
              href={link.target}
              className="text-[14px] font-medium text-secondary-text transition-colors duration-150 hover:text-primary-text"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#apply"
            className="rounded-md bg-fire-orange px-4 py-2 text-[14px] font-medium text-white transition-colors duration-150 hover:bg-deep-orange"
          >
            Apply for Brand Restart
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center rounded-md md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-expanded={mobileOpen}
          aria-controls="mobile-menu"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
        >
          <span className="sr-only">{mobileOpen ? "Close" : "Menu"}</span>
          <div className="flex w-5 flex-col gap-1.5">
            <span
              className={`h-0.5 w-full bg-primary-text transition-transform duration-200 ${
                mobileOpen ? "translate-y-2 rotate-45" : ""
              }`}
            />
            <span
              className={`h-0.5 w-full bg-primary-text transition-opacity duration-200 ${
                mobileOpen ? "opacity-0" : ""
              }`}
            />
            <span
              className={`h-0.5 w-full bg-primary-text transition-transform duration-200 ${
                mobileOpen ? "-translate-y-2 -rotate-45" : ""
              }`}
            />
          </div>
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          id="mobile-menu"
          className="border-t border-border bg-background md:hidden"
        >
          <div className="flex flex-col gap-1 px-5 py-4">
            {navLinks.map((link) => (
              <a
                key={link.target}
                href={link.target}
                onClick={handleLinkClick}
                className="py-3 text-[15px] font-medium text-primary-text"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#apply"
              onClick={handleLinkClick}
              className="mt-2 rounded-md bg-fire-orange px-4 py-3 text-center text-[15px] font-medium text-white"
            >
              Apply for Brand Restart
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

export function Problem() {
  return (
    <section className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7">
            <h2 className="text-[32px] font-semibold leading-[1.15] tracking-tight text-primary-text sm:text-[40px] lg:text-[44px]">
              A strong business should not look smaller than it really is.
            </h2>
          </div>
          <div className="lg:col-span-5 lg:pt-2">
            <p className="mb-6 text-[16px] leading-relaxed text-secondary-text sm:text-[17px]">
              Your customers form an opinion before they contact you. An
              outdated logo, inconsistent colours or weak visual presentation
              can make an established company appear less professional than the
              service it provides.
            </p>
            <p className="text-[16px] font-medium leading-relaxed text-primary-text sm:text-[17px]">
              Brand Restart closes the gap between the business you have built
              and the way it is perceived.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

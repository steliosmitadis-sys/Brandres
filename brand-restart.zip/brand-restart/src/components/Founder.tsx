export function Founder() {
  return (
    <section className="border-t border-border py-20 sm:py-24 lg:py-28">
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-16">
          {/* Portrait placeholder */}
          <div className="lg:col-span-5">
            <div className="aspect-[4/5] overflow-hidden rounded-lg border border-border bg-[#E8E4DC]">
              <div className="flex h-full w-full flex-col items-center justify-center gap-3 text-secondary-text">
                <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-dashed border-secondary-text/30">
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    aria-hidden
                  >
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <span className="text-[13px]">Portrait of Stelios Mytadis</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <h2 className="mb-5 text-[28px] font-semibold tracking-tight text-primary-text sm:text-[36px]">
              Designed personally by Stelios Mytadis
            </h2>
            <p className="max-w-lg text-[16px] leading-relaxed text-secondary-text sm:text-[17px]">
              Brand Restart is a focused design service, not a large agency
              production line. Every identity is researched, designed and
              refined personally, giving your project direct creative attention
              from beginning to end.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
